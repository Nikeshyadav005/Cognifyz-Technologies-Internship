#!/usr/bin/env python
# coding: utf-8

# In[19]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[30]:


df = pd.read_csv("C:/Users/MAHAKAAL/Desktop/Cognifyz Internship/Dataset .csv")


# In[32]:


print("Rows:", len(df))
print("Columns:", len(df.columns))


# In[44]:


print(df.head(5))
print(df.columns)


# In[45]:


df_c = df.copy()
df_c['Cuisines'] = df_c['Cuisines'].fillna('')
df_c['Cuisine_List'] = df_c['Cuisines'].str.split(',').apply(lambda x: [c.strip() for c in x if c.strip() != ''])


# In[ ]:


# Lavel-1


# In[46]:


# Task 1: Top cuisines 
cuisine_counts = df_c.explode('Cuisine_List')['Cuisine_List'].value_counts()
top3_cuisines = cuisine_counts.head(3)


# In[47]:


# percentage of restaurants serving each top cuisine (restaurant-level percentage)
restaurant_has_cuisine = {}
for cuisine in top3_cuisines.index:
    restaurant_has_cuisine[cuisine] = (df_c['Cuisine_List'].apply(lambda lst: cuisine in lst)).mean() * 100.0

print(top3_cuisines)
print(pd.Series(restaurant_has_cuisine))


# In[54]:


# Task 2: City analysis 
city_counts = df_c['City'].value_counts()
city_with_most = city_counts.idxmax()
city_avg_rating = df_c.groupby('City')['Aggregate rating'].mean().sort_values(ascending=False)
city_with_highest_avg = city_avg_rating.index[0]

print(city_counts.head(10))
print(city_with_most)
print(city_avg_rating.head(10))
print(city_with_highest_avg)


# In[56]:


# Task 3: Price range distribution 
plt.figure(figsize=(6,4))
sns.countplot(
    x='Price range',
    hue='Price range',
    data=df_c,
    palette='Blues',
    legend=False
)
plt.title('Distribution of Price Ranges')
plt.xlabel('Price range')
plt.ylabel('Count of restaurants')
plt.tight_layout()
plt.show()

price_pct = (df_c['Price range'].value_counts(normalize=True) * 100).sort_index()
print(price_pct)


# In[90]:


# Task 4: Online delivery 
has_online = df_c['Has Online delivery'].astype(str).str.strip().str.lower().isin(['yes','y','true','1'])
df_c['HasOnlineBool'] = has_online
online_pct = has_online.mean() * 100.0
avg_ratings_by_online = df_c.groupby('HasOnlineBool')['Aggregate rating'].mean()

print(online_pct)
print(avg_ratings_by_online)
print('Completed Level-1 Task 1, Task 2, Task 3 Task 4 analyses and displayed plots')


# In[ ]:





# In[ ]:


#Lavel-2


# In[58]:


# Task 1: Restaurant Ratings
plt.figure(figsize=(6,4))
sns.histplot(df['Aggregate rating'], bins=20, kde=True)
plt.title('Distribution of Aggregate Ratings')
plt.xlabel('Aggregate rating')
plt.ylabel('Count')
plt.show()

rating_bins = pd.interval_range(start=0, end=5, freq=0.5, closed='left')
ratings_binned = pd.cut(df['Aggregate rating'], bins=rating_bins)
most_common_bin = ratings_binned.value_counts().idxmax()
print(most_common_bin)

avg_votes = df['Votes'].mean()
print(avg_votes)

print('Loaded data, plotted ratings, found most common rating bin, and computed average votes')


# In[65]:


# Task 2: Cuisine combinations

# Clean cuisines strings
cuisines_series = df['Cuisines'].fillna('').str.split(',')
# Normalize by stripping spaces and sorting cuisines within a combo for consistency
combo_normalized = cuisines_series.apply(lambda lst: tuple(sorted([x.strip() for x in lst if x.strip() != ''])))

df['Cuisine_Combo'] = combo_normalized

# Count combinations
combo_counts = df['Cuisine_Combo'].value_counts().reset_index()
combo_counts.columns = ['Cuisine_Combo', 'Count']
print(combo_counts.head(10))

# Average rating by combo
combo_rating = df.groupby('Cuisine_Combo')['Aggregate rating'].mean().reset_index().sort_values('Aggregate rating', ascending=False)
print(combo_rating.head(10))

# Plot top 10 most common combos by count
top_common = combo_counts.head(10)
plt.figure(figsize=(8,4))
sns.barplot(data=top_common, x='Count', y=top_common['Cuisine_Combo'].astype(str))
plt.title('Top 10 Most Common Cuisine Combinations')
plt.xlabel('Count')
plt.ylabel('Cuisine Combination')
plt.show()

# Plot top combos by rating (among those with at least 3 rows)
plt.figure(figsize=(8,4))
sns.barplot(data=filtered_combo.head(10), x='Aggregate rating', y=filtered_combo.head(10)['Cuisine_Combo'].astype(str))
plt.title('Top-Rated Cuisine Combos (min 3 occurrences)')
plt.xlabel('Average Aggregate rating')
plt.ylabel('Cuisine Combination')
plt.show()

print('Computed cuisine combos, counts, ratings, and plotted top combos')


# In[73]:


get_ipython().system('pip install geopandas')
get_ipython().system('pip install contextily')


# In[75]:


# Task 3: Geographic Analysis 
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import contextily as ctx

# Build GeoDataFrame from existing df
points_gdf = gpd.GeoDataFrame(df.copy(), geometry=gpd.points_from_xy(df['Longitude'], df['Latitude']), crs='EPSG:4326')
points_web = points_gdf.to_crs(epsg=3857)

# Plot all points with a basemap
ax = points_web.plot(figsize=(6,6), alpha=0.6, markersize=10, color='crimson')
ctx.add_basemap(ax, source=ctx.providers.CartoDB.Positron)
plt.title('Restaurant Locations')
plt.xlabel('Longitude (Web Mercator)')
plt.ylabel('Latitude (Web Mercator)')
plt.show()

# Quick heuristic: count by City to hint at clusters
city_counts = df['City'].value_counts().head(10)
print(city_counts)

print('Plotted locations on a map and summarized top cities')


# In[89]:


# Task 4: Restaurant Chains

chain_stats = df.groupby('Restaurant Name').agg(
    Locations=('Restaurant ID', 'nunique'),
    Avg_Rating=('Aggregate rating', 'mean'),
    Avg_Votes=('Votes', 'mean')
).reset_index()

chains = chain_stats[chain_stats['Locations'] > 1].sort_values(['Locations','Avg_Votes'], ascending=[False, False])
print(chains.head(15))


top_rated_chains = chains[chains['Locations'] >= 3].sort_values('Avg_Rating', ascending=False).head(15)
print(top_rated_chains)

print('Computed chain candidates and summarized ratings and votes')

print('Completed Level-2 Task 1, Task 2, Task 3 Task 4 analyses and displayed plots')


# In[ ]:





# In[ ]:


# level-3


# In[82]:


# Task 1: Restaurant Reviews
import seaborn as sns
from collections import Counter

restaurants = df.copy()

for col in ['Rating text', 'Cuisines']:
    restaurants[col] = restaurants[col].astype(str).str.lower().fillna('')

import re
def simple_tokens(s):
    return re.findall(r'[a-zA-Z]+', s)


tokens = restaurants['Rating text'].apply(simple_tokens)

positive_seed = set(['excellent','very','good','great','awesome','amazing','delicious','tasty','best','love','nice'])
negative_seed = set(['poor','average','bad','terrible','awful','worst','disappointing'])


all_tokens = [t for sub in tokens for t in sub]
counts = Counter(all_tokens)

# Select common positive/negative keywords by intersecting with seeds
pos_keywords = [(w, c) for w, c in counts.items() if w in positive_seed]
neg_keywords = [(w, c) for w, c in counts.items() if w in negative_seed]

pos_keywords_sorted = sorted(pos_keywords, key=lambda x: x[1], reverse=True)
neg_keywords_sorted = sorted(neg_keywords, key=lambda x: x[1], reverse=True)

restaurants['review_len'] = restaurants['Rating text'].str.len()

# Relationship between review length and rating
plt.figure(figsize=(6,4))
sns.scatterplot(x=restaurants['review_len'], y=restaurants['Aggregate rating'], alpha=0.4)
plt.title('Proxy review length vs rating')
plt.show()

corr_len_rating = restaurants[['review_len','Aggregate rating']].corr().iloc[0,1]


# In[83]:


# Task 2: votes Analysis
max_votes_row = restaurants.loc[restaurants['Votes'].idxmax()]
min_votes_row = restaurants.loc[restaurants['Votes'].idxmin()]

corr_votes_rating = restaurants[['Votes','Aggregate rating']].corr().iloc[0,1]

plt.figure(figsize=(6,4))
sns.scatterplot(x=restaurants['Votes'], y=restaurants['Aggregate rating'], alpha=0.4)
plt.title('Votes vs rating')
plt.show()


# In[84]:


# Task 3: Price Range vs. Online Delivery and Table Booking
for col in ['Has Online delivery','Has Table booking']:
    restaurants[col + ' bin'] = restaurants[col].astype(str).str.strip().str.lower().map({'yes':1,'no':0})

# Groupby price range
summary_services = restaurants.groupby('Price range')[['Has Online delivery bin','Has Table booking bin']].mean().reset_index()

print(pd.DataFrame(pos_keywords_sorted, columns=['keyword','count']).head(10))
print(pd.DataFrame(neg_keywords_sorted, columns=['keyword','count']).head(10))
print(restaurants[['Restaurant Name','Votes','Aggregate rating']].loc[[restaurants['Votes'].idxmax(), restaurants['Votes'].idxmin()]])
print(summary_services.head())
print(corr_len_rating)
print(corr_votes_rating)


plt.figure(figsize=(8,4))
sns.lineplot(data=summary_services, x='Price range', y='Has Online delivery bin', marker='o', label='Online delivery rate')
sns.lineplot(data=summary_services, x='Price range', y='Has Table booking bin', marker='o', label='Table booking rate')
plt.ylim(0,1)
plt.title('Service availability by price range')
plt.legend()
plt.show()

print('Completed Level-3 Task 1, Task 2, Task 3 analyses and displayed plots')


# In[ ]:




